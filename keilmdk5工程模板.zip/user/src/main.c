#include "at32f413_board.h"
#include "at32f413_clock.h"

#define pins GPIO_PINS_2|GPIO_PINS_3|GPIO_PINS_5

void led_init(void)
{
	gpio_init_type gpio_init_struct;						//gpio 结构体
 
	/* enable the led clock */
	crm_periph_clock_enable(CRM_GPIOC_PERIPH_CLOCK, TRUE);  //开启gpiod的时钟
 
	/* set default parameter */
	gpio_default_para_init(&gpio_init_struct);				//设置gpio结构体默认值
 
	/* configure the led gpio */
	gpio_init_struct.gpio_drive_strength = GPIO_DRIVE_STRENGTH_STRONGER; 	//较大电流推动/吸入能力
	gpio_init_struct.gpio_out_type  = GPIO_OUTPUT_PUSH_PULL;		 		//推挽或者开漏（输入模式时，这个参数无效）
	gpio_init_struct.gpio_mode = GPIO_MODE_OUTPUT;		 					//输出模式
	gpio_init_struct.gpio_pins = pins;	//IO 管脚
	gpio_init_struct.gpio_pull = GPIO_PULL_NONE; 							//无上下拉
	gpio_init(GPIOC, &gpio_init_struct);
	gpio_bits_reset(GPIOC,pins); 			
	
}

int main(void)
{
  system_clock_config();


  //at32_board_init();
	
	led_init();
	delay_init();
	
  while(1)
  {
    //gpio_bits_reset(GPIOD,pins);
		delay_sec(1);
		//gpio_bits_set(GPIOD,pins);
	}
}

